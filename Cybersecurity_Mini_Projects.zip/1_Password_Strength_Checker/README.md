# Password Strength Checker

This Python script evaluates the strength of passwords.

## Features
- Checks for length, uppercase, lowercase, numbers, and symbols
- Provides suggestions to improve weak passwords

## Skills Demonstrated
- Python programming
- Regex usage
- Basic security awareness

## How to Run
```
python password_checker.py
```