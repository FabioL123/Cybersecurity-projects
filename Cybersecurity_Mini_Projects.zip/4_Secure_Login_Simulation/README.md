# Secure Login Simulation

A simple Flask web app demonstrating secure login with password hashing.

## Features
- User registration and login
- Passwords stored securely with hashing (bcrypt via Werkzeug)
- Demonstrates web security principles

## Skills Demonstrated
- Python and Flask web development
- Password hashing and authentication
- Basic web security concepts

## How to Run
```
pip install flask werkzeug
python app.py
```
Then visit http://127.0.0.1:5000