# Log File Analyzer

Parses log files to detect suspicious activity based on non-200 HTTP responses.

## Features
- Detects repeated failed requests from same IP
- Provides a simple report of suspicious IPs

## Skills Demonstrated
- Python programming
- Pattern recognition
- Security monitoring basics

## How to Run
```
python analyze_logs.py
```